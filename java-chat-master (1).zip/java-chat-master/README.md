# java-chat
A simple java chat application

> Java Chat is a simple chat program  
> which allows for a server with multiple
> client programs to join.
        <ul>
        <li><b>@nickname</b> pour envoyer un Message privé à l'utilisateur 'nickname'</li>
        <li><b>#d3961b</b> pour changer la couleur de son pseudo au code hexadécimal indiquer</li>
        <li><b>;)</b> quelques smileys sont implémentés</li>
        <li><b>flèche du haut</b> pour reprendre le dernier message tapé</li>
        </ul><br/>



<p align="center">
  <a href="https://raw.githubusercontent.com/Drakirus/java-chat/master/screen.png">
    <img alt="ScreenShot~ prompt" src="https://raw.githubusercontent.com/Drakirus/java-chat/master/screen.png">
  </a>
</p>
